-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table hotelchurchure.blogs
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_date` date DEFAULT NULL,
  `status` int NOT NULL,
  `meta_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.blogs: ~0 rows (approximately)

-- Dumping structure for table hotelchurchure.facilities
CREATE TABLE IF NOT EXISTS `facilities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.facilities: ~9 rows (approximately)
INSERT INTO `facilities` (`id`, `title`, `icon`, `details`, `deleted_at`, `created_at`, `updated_at`) VALUES
	(1, 'Rooftop Restaurant & Bar', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">\n                        <path fill="currentColor" d="M416 0C400 0 288 32 288 176V288c0 35.3 28.7 64 64 64h32V480c0 17.7 14.3 32 32 32s32-14.3 32-32V352 240 32c0-17.7-14.3-32-32-32zM64 16C64 7.8 57.9 1 49.7 .1S34.2 4.6 32.4 12.5L2.1 148.8C.7 155.1 0 161.5 0 167.9c0 45.9 35.1 83.6 80 87.7V480c0 17.7 14.3 32 32 32s32-14.3 32-32V255.6c44.9-4.1 80-41.8 80-87.7c0-6.4-.7-12.8-2.1-19.1L191.6 12.5c-1.8-8-9.3-13.3-17.4-12.4S160 7.8 160 16V150.2c0 5.4-4.4 9.8-9.8 9.8c-5.1 0-9.3-3.9-9.8-9L127.9 14.6C127.2 6.3 120.3 0 112 0s-15.2 6.3-15.9 14.6L83.7 151c-.5 5.1-4.7 9-9.8 9c-5.4 0-9.8-4.4-9.8-9.8V16zm48.3 152l-.3 0-.3 0 .3-.7 .3 .7z"/>\n                    </svg>', 'This hotel has an exhilarating restaurant, rooftop bar and open kitchen to serve delicious foods and beverages with a 65" flat TV that makes pleasure to our clients. ', NULL, '2022-09-15 03:26:26', '2022-12-29 04:06:17'),
	(2, 'Free Wi-Fi', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M54.2 202.9C123.2 136.7 216.8 96 320 96s196.8 40.7 265.8 106.9c12.8 12.2 33 11.8 45.2-.9s11.8-33-.9-45.2C549.7 79.5 440.4 32 320 32S90.3 79.5 9.8 156.7C-2.9 169-3.3 189.2 8.9 202s32.5 13.2 45.2 .9zM320 256c56.8 0 108.6 21.1 148.2 56c13.3 11.7 33.5 10.4 45.2-2.8s10.4-33.5-2.8-45.2C459.8 219.2 393 192 320 192s-139.8 27.2-190.5 72c-13.3 11.7-14.5 31.9-2.8 45.2s31.9 14.5 45.2 2.8c39.5-34.9 91.3-56 148.2-56zm64 160c0-35.3-28.7-64-64-64s-64 28.7-64 64s28.7 64 64 64s64-28.7 64-64z"/></svg>', 'The hotel offers Wi-Fi connections in the room and public places.', NULL, '2022-09-15 03:31:59', '2022-11-19 08:45:25'),
	(3, 'Doctor on call', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0S96 57.3 96 128s57.3 128 128 128zm-96 55.2C54 332.9 0 401.3 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7c0-81-54-149.4-128-171.1V362c27.6 7.1 48 32.2 48 62v40c0 8.8-7.2 16-16 16H336c-8.8 0-16-7.2-16-16s7.2-16 16-16V424c0-17.7-14.3-32-32-32s-32 14.3-32 32v24c8.8 0 16 7.2 16 16s-7.2 16-16 16H256c-8.8 0-16-7.2-16-16V424c0-29.8 20.4-54.9 48-62V304.9c-6-.6-12.1-.9-18.3-.9H178.3c-6.2 0-12.3 .3-18.3 .9v65.4c23.1 6.9 40 28.3 40 53.7c0 30.9-25.1 56-56 56s-56-25.1-56-56c0-25.4 16.9-46.8 40-53.7V311.2zM144 448c13.3 0 24-10.7 24-24s-10.7-24-24-24s-24 10.7-24 24s10.7 24 24 24z"/></svg>', 'Pharmacies are nearby, and the famous Bir hospital lies within 10 minute\'s drive. A doctor on call is also available. ', NULL, '2022-09-15 03:32:45', '2022-11-19 08:48:00'),
	(4, 'Travel Desk', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M256 512c141.4 0 256-114.6 256-256S397.4 0 256 0S0 114.6 0 256S114.6 512 256 512zM216 336h24V272H216c-13.3 0-24-10.7-24-24s10.7-24 24-24h48c13.3 0 24 10.7 24 24v88h8c13.3 0 24 10.7 24 24s-10.7 24-24 24H216c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-144c-17.7 0-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32s-14.3 32-32 32z"/></svg>', 'Except for the travel agency guests, the travel desk suggests free information on world heritage sightseeing, cable car, city guide, Everest flight, hiking, vehicle hire, bus tickets, flight tickets, Nepali culture and festivals.', NULL, '2022-09-15 03:34:51', '2022-11-19 08:52:22'),
	(5, 'Elevator', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M132.7 4.7l-64 64c-4.6 4.6-5.9 11.5-3.5 17.4s8.3 9.9 14.8 9.9H208c6.5 0 12.3-3.9 14.8-9.9s1.1-12.9-3.5-17.4l-64-64c-6.2-6.2-16.4-6.2-22.6 0zM64 128c-35.3 0-64 28.7-64 64V448c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V192c0-35.3-28.7-64-64-64H64zm96 192c-26.5 0-48-21.5-48-48s21.5-48 48-48s48 21.5 48 48s-21.5 48-48 48zM80 400c0-26.5 21.5-48 48-48h64c26.5 0 48 21.5 48 48v16c0 17.7-14.3 32-32 32H112c-17.7 0-32-14.3-32-32V400zm192 0c0-26.5 21.5-48 48-48h64c26.5 0 48 21.5 48 48v16c0 17.7-14.3 32-32 32H304c-17.7 0-32-14.3-32-32V400zM400 272c0 26.5-21.5 48-48 48s-48-21.5-48-48s21.5-48 48-48s48 21.5 48 48zM356.7 91.3c6.2 6.2 16.4 6.2 22.6 0l64-64c4.6-4.6 5.9-11.5 3.5-17.4S438.5 0 432 0H304c-6.5 0-12.3 3.9-14.8 9.9s-1.1 12.9 3.5 17.4l64 64z"/></svg>', 'The hotel elevator with four people capacity takes the room and rooftop bar. ', NULL, '2022-09-23 03:35:08', '2022-11-19 09:01:36'),
	(6, 'Air-Conditioners', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M258.6 0c-1.7 0-3.4 .1-5.1 .5C168 17 115.6 102.3 130.5 189.3c2.9 17 8.4 32.9 15.9 47.4L32 224H29.4C13.2 224 0 237.2 0 253.4c0 1.7 .1 3.4 .5 5.1C17 344 102.3 396.4 189.3 381.5c17-2.9 32.9-8.4 47.4-15.9L224 480v2.6c0 16.2 13.2 29.4 29.4 29.4c1.7 0 3.4-.1 5.1-.5C344 495 396.4 409.7 381.5 322.7c-2.9-17-8.4-32.9-15.9-47.4L480 288h2.6c16.2 0 29.4-13.2 29.4-29.4c0-1.7-.1-3.4-.5-5.1C495 168 409.7 115.6 322.7 130.5c-17 2.9-32.9 8.4-47.4 15.9L288 32V29.4C288 13.2 274.8 0 258.6 0zM256 288c-17.7 0-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32s-14.3 32-32 32z"/></svg>', 'Hotel Simal has a central air conditioner for every guest room.', NULL, '2022-09-23 03:41:39', '2022-10-13 19:04:42'),
	(7, 'Rooftop garden', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M210.6 5.9L62 169.4c-3.9 4.2-6 9.8-6 15.5C56 197.7 66.3 208 79.1 208H104L30.6 281.4c-4.2 4.2-6.6 10-6.6 16C24 309.9 34.1 320 46.6 320H80L5.4 409.5C1.9 413.7 0 419 0 424.5c0 13 10.5 23.5 23.5 23.5H192v32c0 17.7 14.3 32 32 32s32-14.3 32-32V448H424.5c13 0 23.5-10.5 23.5-23.5c0-5.5-1.9-10.8-5.4-15L368 320h33.4c12.5 0 22.6-10.1 22.6-22.6c0-6-2.4-11.8-6.6-16L344 208h24.9c12.7 0 23.1-10.3 23.1-23.1c0-5.7-2.1-11.3-6-15.5L237.4 5.9C234 2.1 229.1 0 224 0s-10 2.1-13.4 5.9z"/></svg>', 'The rooftop garden presents Kathmandu valley with Ganesh with Langtang Himalayas, sunrise, and sunset views. It can observe tourist towns Thamel, Sorhakhutte, Sheraton Hotel, Aloft Hotel, UNESCO world heritage Swayambhunath Stupa, Bhimsen Tower, Shivapuri National Park, Nagarjun Hill, Chandragiri Hill and different places.', NULL, '2022-09-23 03:46:10', '2022-11-19 09:17:09'),
	(8, 'Parking', '<svg xmlns="https://www.iconpacks.net/free-icon/parking-1641.html">\n\n<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAAAXNSR0IArs4c6QAAADVJREFUSEvt0rEJAAAMAkHdf2lH+MruU0uEw+Z8Pf+PBSgskUQogAFXJBEKYMAVSYQCGLivaHrEABkDr5mAAAAAAElFTkSuQmCC"/>', '24/7 Underground Parking', '2022-09-23 09:33:12', '2022-09-23 09:32:09', '2022-09-23 09:33:12'),
	(9, 'Parking', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--! Font Awesome Pro 6.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. --><path fill="currentColor" d="M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V96c0-35.3-28.7-64-64-64H64zM192 256h48c17.7 0 32-14.3 32-32s-14.3-32-32-32H192v64zm48 64H192v32c0 17.7-14.3 32-32 32s-32-14.3-32-32V288 168c0-22.1 17.9-40 40-40h72c53 0 96 43 96 96s-43 96-96 96z"/></svg>', 'This hotel maintains underground parking for 20 motorbikes and six cars.  ', NULL, '2022-09-25 09:47:54', '2022-12-29 04:07:05');

-- Dumping structure for table hotelchurchure.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table hotelchurchure.galleries
CREATE TABLE IF NOT EXISTS `galleries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `caption` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.galleries: ~8 rows (approximately)
INSERT INTO `galleries` (`id`, `caption`, `created_at`, `updated_at`) VALUES
	(5, 'single room', '2022-12-03 00:57:33', '2022-12-03 00:57:33'),
	(6, 'family bed with balcony', '2022-12-03 00:58:06', '2022-12-03 00:58:06'),
	(7, 'family bed with balcony', '2022-12-03 01:02:13', '2022-12-03 01:02:13'),
	(8, 'twin bed room', '2022-12-03 01:10:31', '2022-12-03 01:10:31'),
	(9, 'hotel simal building', '2022-12-03 01:13:50', '2022-12-03 01:13:50'),
	(10, 'hotel simal lobby', '2022-12-03 01:21:58', '2022-12-03 01:21:58'),
	(11, 'hotel simal bar & restaurant', '2022-12-03 01:24:47', '2022-12-03 01:24:47'),
	(12, 'hotel simal staff', '2022-12-03 01:27:09', '2022-12-03 01:27:09');

-- Dumping structure for table hotelchurchure.labels
CREATE TABLE IF NOT EXISTS `labels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `page` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `label_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.labels: ~5 rows (approximately)
INSERT INTO `labels` (`id`, `page`, `label_id`, `value`, `created_at`, `updated_at`) VALUES
	(2, 'contact', 'contact:emails', 'info@hotelchurchure.com', '2022-11-18 02:02:17', '2024-05-19 21:38:28'),
	(3, 'contact', 'contact:address', 'Paknajol-16, Kathmandu, Nepal', '2022-11-18 02:13:34', '2022-11-20 20:04:05'),
	(4, 'contact', 'contact:phones', '+977-01-0000000', '2022-11-18 02:14:04', '2024-05-19 21:38:52'),
	(5, 'global', 'global:emails', 'info@hotelchurchure.com', '2022-12-02 05:23:25', '2024-05-19 21:38:14'),
	(6, 'global', 'global:phones', '+977-01-0000000', '2022-12-02 05:23:53', '2024-05-19 21:38:45');

-- Dumping structure for table hotelchurchure.media
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.media: ~25 rows (approximately)
INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
	(26, 'App\\Models\\Room', 2, 'fe902145-8856-43ca-b82d-39ea900b54bb', 'rooms', '16', 'QH7t5h4g5UnBUvm7uhGLnDTDen6y5V-metaMTYuanBn-.jpg', 'image/jpeg', 'public', 'public', 189676, '[]', '[]', '[]', '[]', 1, '2022-11-18 03:17:15', '2022-11-18 03:17:15'),
	(27, 'App\\Models\\Room', 3, '48becbf8-783a-4cdd-82f4-c367be055ee5', 'rooms', '25', '8YlgZEbAi7BmoDO1i8O1bAwWmdBEjp-metaMjUuanBn-.jpg', 'image/jpeg', 'public', 'public', 233384, '[]', '[]', '[]', '[]', 1, '2022-11-18 03:18:44', '2022-11-18 03:18:44'),
	(32, 'App\\Models\\Room', 4, 'a841aa19-26a9-405e-a03f-db5353717fd6', 'rooms', 'sweet-room-with-balcony', 'BGphp2d2tx2lmIOoHT1Z8GHRAL5s4n-metac3dlZXQtcm9vbS13aXRoLWJhbGNvbnkuanBn-.jpg', 'image/jpeg', 'public', 'public', 309717, '[]', '[]', '[]', '[]', 1, '2022-11-18 04:24:13', '2022-11-18 04:24:13'),
	(36, 'App\\Models\\Room', 5, '195fd68d-9e14-40ab-b779-a8886b39275d', 'rooms', 'deluxe-king-room', 'BxAyTNgGK386wlFKQ5wFAat5HWhJRZ-metaZGVsdXhlLWtpbmctcm9vbS5qcGc=-.jpg', 'image/jpeg', 'public', 'public', 233384, '[]', '[]', '[]', '[]', 1, '2022-11-18 22:16:47', '2022-11-18 22:16:47'),
	(38, 'App\\Models\\Recommendation', 1, '2635fcbb-4e91-4f11-9205-669b821f1ab4', 'recommendation', 'eP4nJbGkvW8R2TWTr8RF9HlCGQgqhH-metaVHJpcGFkdmlzb3JfbG9ja3VwX2hvcml6b250YWxfc2Vjb25kYXJ5X3JlZ2lzdGVyZWRbMl0uc3Zn-', 'qUMgLIxJotGvw3KvoBdWe2c97wB0nZ-metaZVA0bkpiR2t2VzhSMlRXVHI4UkY5SGxDR1FncWhILW1ldGFWSEpwY0dGa2RtbHpiM0pmYkc5amEzVndYMmh2Y21sNmIyNTBZV3hmYzJWamIyNWtZWEo1WDNKbFoybHpkR1Z5WldSYk1sMHVjM1puLS5zdmc=-.svg', 'image/svg+xml', 'public', 'public', 5650, '[]', '[]', '[]', '[]', 1, '2022-12-01 11:35:51', '2022-12-01 11:35:51'),
	(39, 'App\\Models\\Recommendation', 2, '767708e0-d858-4b97-9c8d-f2f7812c3c2f', 'recommendation', 'Lxeq9mCkDmRdaFyodt4wDMnLvAH9fy-metaYWdvZGFbMV0ucG5n-', '0ThX3ObzJGxYk9eP8moGrJHlEviMnB-metaTHhlcTltQ2tEbVJkYUZ5b2R0NHdETW5MdkFIOWZ5LW1ldGFZV2R2WkdGYk1WMHVjRzVuLS5wbmc=-.png', 'image/png', 'public', 'public', 4159, '[]', '[]', '[]', '[]', 1, '2022-12-01 11:36:10', '2022-12-01 11:36:10'),
	(41, 'App\\Models\\Recommendation', 3, 'ba192d5c-6267-4b87-b8f5-371cd90f8d40', 'recommendation', 'Srzw0Ld4GI4yjnrxUZF5xrZ9Eou4IU-metaYm9va2luZy1jb21bMV0ucG5n-', 'DAVyo2yOUqO96i0vPbusC5unulh5e4-metaU3J6dzBMZDRHSTR5am5yeFVaRjV4clo5RW91NElVLW1ldGFZbTl2YTJsdVp5MWpiMjFiTVYwdWNHNW4tLnBuZw==-.png', 'image/png', 'public', 'public', 10636, '[]', '[]', '[]', '[]', 1, '2022-12-02 08:50:17', '2022-12-02 08:50:17'),
	(42, 'App\\Models\\Recommendation', 4, '1bf6383e-7afd-4c18-9021-5ddfa1ecbe38', 'recommendation', 'logo[1]', '89DF2ICGIfTHCY0eFmbkXum3rCYMK1-metabG9nb1sxXS5zdmc=-.svg', 'image/svg+xml', 'public', 'public', 4888, '[]', '[]', '[]', '[]', 1, '2022-12-02 08:51:57', '2022-12-02 08:51:57'),
	(43, 'App\\Models\\Room', 2, '3094ed3e-ae1b-4309-9f7b-73a590949e9e', 'rooms', 'ThnYU7FQHCJQDmlO9ZehPpTrtrrOBD-metaMjYuanBn-[1]', 'mECEjANbtw15koVNjLgsXcrkYSUtQA-metaVGhuWVU3RlFIQ0pRRG1sTzlaZWhQcFRydHJyT0JELW1ldGFNall1YW5Cbi1bMV0uanBn-.jpg', 'image/jpeg', 'public', 'public', 186302, '[]', '[]', '[]', '[]', 2, '2022-12-02 09:07:58', '2022-12-02 09:07:58'),
	(45, 'App\\Models\\Room', 1, '71c01e35-aedb-4dee-860d-dfde33cbf704', 'rooms', 'single-room-simal', '4HMuHxMEE5WurKWzTOtkoMVZEIiHxn-metac2luZ2xlLXJvb20tc2ltYWwuanBn-.jpg', 'image/jpeg', 'public', 'public', 198410, '[]', '[]', '[]', '[]', 2, '2022-12-03 00:16:04', '2022-12-03 00:16:04'),
	(46, 'App\\Models\\Room', 4, '52090422-3e1b-4d8f-9f05-0d61d87c29f7', 'rooms', 'sweet-room with balcony', 'W4YJDm78EulPnNFRqDDs1T8XjtzHv8-metac3dlZXQtcm9vbSB3aXRoIGJhbGNvbnkuanBn-.jpg', 'image/jpeg', 'public', 'public', 245762, '[]', '[]', '[]', '[]', 2, '2022-12-03 00:23:12', '2022-12-03 00:23:12'),
	(47, 'App\\Models\\Room', 5, '3855f1c2-b418-4768-a600-a746051e0d71', 'rooms', 'master-bed-hotel-simal', 'lS277kd6PdIhITu3UbOKBUlAYw9Yha-metabWFzdGVyLWJlZC1ob3RlbC1zaW1hbC5qcGc=-.jpg', 'image/jpeg', 'public', 'public', 233746, '[]', '[]', '[]', '[]', 2, '2022-12-03 00:54:50', '2022-12-03 00:54:50'),
	(48, 'App\\Models\\Gallery', 5, 'fe2019af-8cfc-4ec4-8e98-47a3aafeddeb', 'gallery', 'single-room-simal', 'lPZ6ztIkbaXUm61t9EWsQEyXb0yGsB-metac2luZ2xlLXJvb20tc2ltYWwuanBn-.jpg', 'image/jpeg', 'public', 'public', 198410, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 00:57:34', '2022-12-03 00:57:34'),
	(49, 'App\\Models\\Gallery', 6, '2ca10c43-b0e4-4cb8-8b68-143c575c9bcd', 'gallery', 'sweet-room with balcony', '0KEzhxyADsKioieXOMqCF0b6Vp527x-metac3dlZXQtcm9vbSB3aXRoIGJhbGNvbnkuanBn-.jpg', 'image/jpeg', 'public', 'public', 245762, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 00:58:06', '2022-12-03 00:58:07'),
	(50, 'App\\Models\\Gallery', 7, 'fafb98bb-0870-4635-b3d6-f539a2510ef5', 'gallery', 'double-bed-simal', 'j5YhBW1cuco1ogIE4akwxzClL3xlck-metaZG91YmxlLWJlZC1zaW1hbC5qcGc=-.jpg', 'image/jpeg', 'public', 'public', 229072, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:02:14', '2022-12-03 01:02:14'),
	(51, 'App\\Models\\Gallery', 8, 'e309c0bd-25d8-437b-82e2-21adaea16f95', 'gallery', 'twins-bed-room', 'GArr429hVjX5sG4m3B2xV01ZViHrgS-metadHdpbnMtYmVkLXJvb20uanBn-.jpg', 'image/jpeg', 'public', 'public', 269409, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:10:31', '2022-12-03 01:10:31'),
	(52, 'App\\Models\\Gallery', 9, '4ee17bc3-1402-435b-8b97-b561077f2fe3', 'gallery', 'hotel-simal-building', 'TLcjSVqxLc0UYO2i43aztk3htUYOri-metaaG90ZWwtc2ltYWwtYnVpbGRpbmcuanBn-.jpg', 'image/jpeg', 'public', 'public', 1015351, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:13:51', '2022-12-03 01:13:58'),
	(53, 'App\\Models\\Gallery', 10, 'c7479f33-d90e-4a20-b19d-5fe425d5e458', 'gallery', 'hotel-lobby', 'u6TeavshGPKjsJTLKZLd4gZMm12pCY-metaaG90ZWwtbG9iYnkuanBn-.jpg', 'image/jpeg', 'public', 'public', 947531, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:21:59', '2022-12-03 01:22:04'),
	(54, 'App\\Models\\Gallery', 11, '60ff9147-5a58-40c4-ac21-75150ca815ae', 'gallery', 'restaurant-and-bar', 'Cy9KqXrhVYTB4cuXTeHn1sEfEuoTHQ-metacmVzdGF1cmFudC1hbmQtYmFyLmpwZw==-.jpg', 'image/jpeg', 'public', 'public', 900049, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:24:47', '2022-12-03 01:24:53'),
	(55, 'App\\Models\\Gallery', 12, '4d09dfeb-b8ff-41ba-bff9-a3c16f34ab11', 'gallery', 'hotel-simal-staff', 'C1zKziEC4JmYMUeIvYMUUm7yPo0CZ7-metaaG90ZWwtc2ltYWwtc3RhZmYuanBn-.jpg', 'image/jpeg', 'public', 'public', 137600, '[]', '[]', '{"thumb": true}', '[]', 1, '2022-12-03 01:27:09', '2022-12-03 01:27:09'),
	(56, 'App\\Models\\Room', 1, '5a2b7730-7337-401a-8f55-35051f678fe0', 'rooms', 'single-deluxe-room', 'F3qocfu5ewJqmA7IfKksEers3TItzb-metac2luZ2xlLWRlbHV4ZS1yb29tLmpwZw==-.jpg', 'image/jpeg', 'public', 'public', 90608, '[]', '[]', '[]', '[]', 3, '2023-01-09 20:45:14', '2023-01-09 20:45:14'),
	(57, 'App\\Models\\Slide', 11, 'f740b7ab-9ae9-4309-a940-ffc7b5ffdedf', 'slides', 'slide image', 'cAByfVysuuy9ZJXtQc40XS9N67Pfgt-metac2xpZGUgaW1hZ2UuanBn-.jpg', 'image/jpeg', 'public', 'public', 273210, '[]', '[]', '[]', '[]', 1, '2023-01-20 22:27:42', '2023-01-20 22:27:42'),
	(58, 'App\\Models\\Slide', 9, '2585c035-9b1e-4058-a4cc-b23772c92b5b', 'slides', 'slide-photo-room', 'AA55NX8thWPTS0wOWSlxg27uLZPtTr-metac2xpZGUtcGhvdG8tcm9vbS5qcGc=-.jpg', 'image/jpeg', 'public', 'public', 243111, '[]', '[]', '[]', '[]', 1, '2023-01-20 22:28:57', '2023-01-20 22:28:57'),
	(59, 'App\\Models\\Slide', 10, 'd34c19e1-ff71-4903-aa07-e7a87bffff7f', 'slides', 'restaurant-of-hotel-simal-s', '9fCtL7erY9Cwbs05ic0LsoOCQFM2bm-metacmVzdGF1cmFudC1vZi1ob3RlbC1zaW1hbC1zLmpwZw==-.jpg', 'image/jpeg', 'public', 'public', 221226, '[]', '[]', '[]', '[]', 1, '2023-01-20 22:29:31', '2023-01-20 22:29:31'),
	(60, 'App\\Models\\Slide', 2, 'e221b17d-9be4-4f02-a71c-d895ccf32a40', 'slides', 'hotel-simal-lobby', '7vzZVKc12LzodLexReKYNbn0gV96gH-metaaG90ZWwtc2ltYWwtbG9iYnkuanBn-.jpg', 'image/jpeg', 'public', 'public', 264838, '[]', '[]', '[]', '[]', 1, '2023-01-20 22:30:19', '2023-01-20 22:30:19');

-- Dumping structure for table hotelchurchure.menus
CREATE TABLE IF NOT EXISTS `menus` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `menu` varchar(255) NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Dumping data for table hotelchurchure.menus: ~2 rows (approximately)
INSERT INTO `menus` (`id`, `menu`, `status`, `created_at`, `updated_at`) VALUES
	(4, 'Main Menu', 1, '2022-07-22 00:36:20', '2022-12-06 20:55:42'),
	(5, 'Footer', 1, '2022-07-22 00:36:49', '2022-07-22 00:36:49');

-- Dumping structure for table hotelchurchure.menu_page
CREATE TABLE IF NOT EXISTS `menu_page` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `menu_id` int NOT NULL,
  `page_id` int NOT NULL,
  `order_by` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.menu_page: ~15 rows (approximately)
INSERT INTO `menu_page` (`id`, `menu_id`, `page_id`, `order_by`) VALUES
	(1, 4, 2, NULL),
	(2, 5, 3, NULL),
	(3, 4, 3, NULL),
	(4, 4, 5, NULL),
	(5, 5, 7, NULL),
	(6, 4, 7, NULL),
	(7, 5, 5, NULL),
	(8, 4, 8, NULL),
	(9, 5, 8, NULL),
	(10, 4, 9, NULL),
	(11, 5, 9, NULL),
	(20, 4, 15, NULL),
	(21, 4, 10, NULL),
	(23, 4, 16, NULL),
	(24, 4, 13, NULL);

-- Dumping structure for table hotelchurchure.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.migrations: ~9 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2022_09_14_163806_create_media_table', 2),
	(7, '2022_09_15_064237_create_rooms_table', 3),
	(9, '2022_09_15_090021_create_facilities_table', 4),
	(11, '2022_09_15_102343_create_reviews_table', 5),
	(13, '2022_09_15_105735_add_is_featured_column_in_reviews_table', 6);

-- Dumping structure for table hotelchurchure.pages
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `overview` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `position` int DEFAULT NULL,
  `order_by` int DEFAULT NULL,
  `menu_order` int DEFAULT NULL,
  `footer_order` int DEFAULT NULL,
  `meta_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.pages: ~9 rows (approximately)
INSERT INTO `pages` (`id`, `parent_id`, `title`, `slug`, `overview`, `details`, `status`, `position`, `order_by`, `menu_order`, `footer_order`, `meta_title`, `meta_keyword`, `meta_description`, `created_at`, `updated_at`) VALUES
	(5, 0, 'Home', 'home', NULL, '<p>Warm greetings at Hotel Simal acknowledges the government-registered tourist hotel nestled on the border of Thamel, Paknajol, and Sorhakhutte in Kathmandu. Some 40 well-furnished rooms categorising single, double, twin and balcony sweet attached hot shower, TV, Wi-Fi, underground parking, central air-conditioning, an elevator, a rooftop restaurant &amp; bar, housekeeping service, a mini meeting hall, and outstanding views of Kathmandu city, valley, Swayambhunath, Shivapuri Nagarjun National Park, Bhimsen tower, Thamel, Sheraton hotel, Ganesh and Langtang Himalayas. The hotel has access to The Garden of Dream, Asan Bazaar, Kathmandu Durbar Square, Balaju Water Garden, and a local and tourist bus stop. Book directs to Hotel Simal for visitors service and Nepal government tax without commission.</p>', 1, NULL, NULL, NULL, NULL, 'Nepal hotel booking | Kathmandu hotel booking | Hotel Simal ', 'Nepal hotel booking, Kathmandu hotel booking, Hotel Simal Kathmandu, Place to eat, Place to stay, Hotel booking in Thamel Kathmandu ', 'Kathmandu Nepal hotel booking at Hotel Simal in Thamel Paknajol with parking, lift, AC and bar have the views of Swayambhunath, Kathmandu valley & Himalayas.', '2022-07-22 02:48:27', '2024-04-04 02:43:09'),
	(7, 0, 'About us', 'about-us', NULL, '<p>Among peaceful and comfortable hotels in Kathmandu, the white building Hotel Simal is 150 meters east of Sorhakhutte Police Station, 50 meters southwest of Thamel Z Street specified centre location for Kathmandu travellers. The hotel lies on the border of Paknajol, tourist hub Thamel and the historic town Sorhakhutte. Hotel Simal is a gateway to Thamel, Sorhakhutte Local and Tourist bus stop, Narayanhiti Palace Museum, The Garden of Dream, Asan bazaar, heritage sites Kathmandu Durbar Square and Swayambhunath Stupa. Marked by its exceptional location, Hotel Simal denotes friendly and satisfying services with the most peaceful and relaxing environment for Kathmandu visitors.</p><p>Hotel Simal offers an elegant atmosphere with the most comfortable accommodation in Kathmandu. The hotel welcomes our guests with 40 air-conditioning different budget rooms, friendly staff, a hot shower, underground parking, delicious foods, beverages, free Wi-Fi and housekeeping service. The rooftop restaurant and bar with a 65" flat TV and meeting room are unique. The rooftop Garden offers the scenic beauty of the Kathmandu valley in the city, green hills, Swyambhunath and Himalayas views.</p><p>Avoiding the hustle, bustle and noise of the Thamel, Hotel Simal Paknajol is near a great alternate location. Next to Thamel (west), Paknajol is a long street that leads to the must-see attractions of Swyambunath (monkey temple), Thamel and Kathmandu Durbar Square. For a quieter selection to Thamel, book directly to the website of Hotel Simal without commission for a comfortable air conditioning room, hot shower and terrace view restaurant and bar service.</p><p>Sorhakhutte is a settlement of Kathmandu city lying at an intersection of Thamel, Asan, Swayambhu, Kathmandu Durbar and Balaju Water Garden. The tourist bus stop and the famous Ganesh Temple are ten minutes distance. Sorhakhutte Pati is a historic public resthouse with 16 wooden pillars renovated in 2015 due to road expansion.&nbsp;</p>', 0, NULL, NULL, NULL, NULL, 'Hotel Simal Paknajol Kathmandu | Hotel Simal info', 'Hotel Simal Kathmandu Nepal, Nepal Hotel booking, Kathmandu hotel information, Kathmandu hotel booking ', 'Hotel simal is a government-registered tourist hotel in Thamel Paknajol Kathmandu with parking, AC, a lift, Bar with views of the valley and the Himalayas.', '2022-07-22 03:01:36', '2024-04-04 02:44:28'),
	(8, 0, 'Rooms', 'rooms', NULL, '<p>Rooms</p>', 1, NULL, NULL, NULL, NULL, 'Hotel Simal room | Room category at Hotel Simal | Room Prices', 'Hotel Simal rooms, Types of rooms at Hotel Simal Paknajol Kathmandu', 'Hotel Simal offers different types of rooms for budget travellers in Thamel, Paknajol, Kathmandu, Nepal at affordable prices for comfortable stays, food & drink. ', '2022-07-25 10:52:16', '2022-11-18 09:10:16'),
	(9, 0, 'Facilities', 'facilities', NULL, '<p><a href="http://hotelsimal.com.test/#">Service and Facility</a></p><p><br></p>', 1, NULL, NULL, NULL, NULL, 'Hotel Simal Facilities | Hotel Simal amenities ', 'Hotel Simal Facilities, Hotel Simal amenities', 'Hotel Simal Facilities have comfortable accommodation, parking, air conditioning, a bar, housekeeping, hot shower, TV and food in Thamel Paknajol Kathmandu. ', '2022-09-14 11:04:38', '2022-11-18 09:23:30'),
	(10, 0, 'Gallery', 'gallery', NULL, '<p>Gallery</p>', 1, NULL, NULL, NULL, NULL, 'Photos', 'gallery of hotel simal, hotel simal photo', 'The gallery of the hotel simal exhibits beautiful photos of the property, such as the exterior and interior images of the building, rooms, lobby and terrace view.', '2022-09-14 11:04:52', '2023-01-20 22:05:20'),
	(13, 0, 'Contact us', 'contact-us', NULL, '<h3>Hotel Simal Pvt. Ltd.&nbsp;</h3><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</p><p><br></p><p><br></p><p><a href="https://www.google.com/maps/place/Hotel+Simal+Pvt.+Ltd./@27.7172673,85.3068892,17z/data=!3m1!4b1!4m5!3m4!1s0x39eb1965f1df2047:0x5cfa6f3134e2c54f!8m2!3d27.7172673!4d85.3090779">Location Map</a></p>', 1, NULL, NULL, NULL, NULL, 'Hotel Simal Contact | Hotel Simal Telephones | Hotel Simal mailing address', 'Hotel Simal Contact, Hotel Simal Telephones, Hotel Simal mailing address ', 'Hotel Simal Contact with its telephone numbers and mailing address at Thamel, Paknajol, Kathmandu, Nepal for food, accommodation, parking & meeting room booking.', '2022-09-14 11:06:15', '2023-02-13 00:13:24'),
	(14, 0, 'Reviews', 'reviews', NULL, '<p>Reviews</p>', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-09-15 05:31:00', '2022-12-02 02:26:49'),
	(15, 0, 'Menu', 'menu', NULL, '<p><strong>Breakfast Selections</strong></p><p><strong>Set Breakfast</strong></p><p><strong>Continental Breakfast </strong>- Rs. 400</p><p>(Choices of chilled juice of fresh seasonal fruits, toast and croissant served with butter and preserves, saute potato, omelette, tea/coffee)</p><p><strong>Indian Breakfast</strong> - Rs. 590</p><p>(Choices of chilled juice of fresh seasonal fruits, chilled lassi (plain, sweet or salted), masala omelette, puri bhaji or aloo paratha with curd, tea or coffee)</p><p><strong>American Breakfast</strong> - Rs. 690</p><p>(Choices of chilled juice or fresh or fresh seasonal fruits, cornflakes muesli or oatmeal (served with cold or hot milk, (Two fresh farm eggs cooked to your order, ham, bacon or sausage, toast and croissant served with butter and preserves) hash brown potato, tea/coffee)</p><p><strong>A La Carte</strong></p><p><strong>Juice / Salad</strong></p><p>Orange / Pineapple / Mango - Rs. 200</p><p>Mixed Juice - Rs. 250</p><p>Fresh Fruit Salad - Rs. 250</p><p>Fresh Fruit Platter - Rs. 450</p><p>Fresh Fruit Salad with Yoghurt - Rs. 300</p><p><strong>Green Salad</strong> - Rs. 300</p><p>(Fresh tomato, cucumber, carrot, onion, lemon, wedges &amp; green chilly)</p><p>Egg (Two farm eggs cooked to your order)</p><p>Ham/Bacon/Sausage - Rs. 250</p><p>Baked Bean /Toast - Rs. 250</p><p>Poached/Fried - Rs. 200</p><p><strong>Puri Bhaji</strong> - Rs. 290</p><p>(Deep-fried puffy Indian bread served with spicy vegetables)</p><p><strong>Aaloo Paratha with curd</strong> - Rs. 250</p><p>(Stuffed bread with potatoes)</p><p><strong>French Toast</strong> - Rs. 290</p><p>(Grilled toast covered with an egg from our bakery)</p><p><strong>Toast White or Brown Bread</strong> - Rs. 150</p><p>(Served with butter &amp; preserves)</p><p><strong>Muffins </strong>- Rs. 150</p><p>(Served with butter &amp; preserves)</p><p><strong>Croissant </strong>- Rs. 150</p><p>(Served with butter &amp; preserves)</p><p>Pancake with Honey - Rs. 250</p><p>Appetizers</p><p><strong>Salad</strong></p><p><strong>Russian Salad</strong> - Rs. 450</p><p>(Fresh potato, green beans, green peas, apple, boiled eggs, marinated mayonnaise cream, salt pepper, sugar)</p><p>Greek Salad - Rs. 400</p><p>(Green mixed lettuce, tomato, cucumber, onion, bell pepper, olive, feta cheese, lemon, vinegar dressing)</p><p><strong>Green Salad</strong> - Rs. 250</p><p>(Fresh tomato, cucumber, carrot, onion, radish, lemon wedge &amp; green chilly)</p><p><strong>Chicken Smoke Salad</strong> - Rs. 600</p><p>(Tomato, lettuce, cucumber, capsicum, onion, sarrot cut with mayonnaise salad)</p><p><strong>Nepali Salad</strong> (Finger Cut) - Rs. 300</p><p>(Fresh tomato, cucumber, carrot, onion, radish, lemon wedge, green chilly)</p><p><strong>Beetroot Salad</strong> - Rs. 350</p><p>(Topped with sesame seed)</p><p><strong>Chef Special Salad</strong> - Rs. 700</p><p>(Lettuce, carrot, cucumber, cheese, paneer, sausage, chicken, tuna, beans, topped with a boiled egg)</p><p><strong>Soup</strong></p><p>Cream of Asparagus Soup - Rs. 290</p><p>Non - Vegetables - Rs. 290</p><p>Mushroom Soup - Rs. 300</p><p><strong>Sweet Corn Chicken Soup</strong> - Rs. 290</p><p>(Boiled roast chicken chopped creamy style fresh garden corn mixed)</p><p><strong>Hot &amp; sour Soup</strong> - Rs. 350</p><p>(Prawn, chicken, fine chopped bamboo shoots, bean, curd, sesame oil, spring onion)</p><p><strong>Vegetable Hot &amp; Sour Soup</strong> - Rs. 350</p><p>(Mixed vegetables fine chopped, bamboo shoot, bean curd, sesame oil, spring onion)</p><p>Cream of Tomato Soup - Rs. 250</p><p><strong>Thukpa</strong></p><p>Thai Style Chicken Thukpa - Rs. 300</p><p>Vegetarian - Rs. 250</p><p>Non-Vegetarian with spicy mixed - Rs. 400</p><p><strong>Thali Set</strong></p><p><strong>Vegetable Thali Set</strong> - Rs. 500</p><p>Basmati rice, typical Nepali style paneer, mutter curry, Daal fried, vegetables, rayo saag, Pickle, salad, yoghurt &amp; dry papad</p><p><strong>Mutton Thali Set</strong> - Rs. 750</p><p>(Simal Special Thali Set)</p><p>Vegetable thali with typical Nepali-style mutton curry</p><p><strong>Chicken Thali Set</strong> - Rs. 650</p><p>Vegetable Thali without paneer curry, Typical Nepali-style chicken curry</p><p><strong>All Day Dining</strong></p><p><strong>Fish &amp; Chips</strong> - Rs. 500</p><p>(Deep fried fish filled served with french fry, tartar sauce)</p><p><strong>Chicken Sizzler</strong> - Rs. 600</p><p>(Grilled boneless chicken accompanied with potato wedge, grilled vegetables &amp; mushroom sauce served on the sizzling hot dish)</p><p><strong>Stroganoff Beef</strong> - Rs. 690</p><p>(Choice of shredded beef sauteed with onion, fresh mushroom cooked with Demi-Glace sauce served with butter rice &amp; seasonal vegetables)</p><p><strong>Chicken in the Basket</strong> - Rs. 550</p><p>(Crispy golden fried chicken served with french fries &amp; tartar sauce)</p><p><strong>Chicken Shashlik</strong> - Rs. 550</p><p>(Cubes of the chicken skewer on a traditional bamboo stick with sliced tomato capsicum, and onion &amp; grilled and served with mushroom sauce &amp; garlic rice)</p><p><strong>Pepper Steak</strong> - Rs. 690</p><p>(Cooked to your liking rare, medium or well done, served with wedge potato vegetables, cracked black pepper, mushroom sauce, normal plate or sizzling dish)</p><p><strong>Pork Chop</strong> - Rs. 690</p><p>(Grilled port chop served with potato wedge, apple sauce served with butter rice &amp; seasonal vegetables)</p><p><strong>Beef Lasagna</strong> - Rs. 590</p><p>(Rish lasagna with minced beef tomato puree sauce, moray sauce, garnished with cheese)</p><p>Grilled Chicken - Rs. 550</p><p><strong>Vegetables Jhalferzi</strong> - Rs. 390</p><p>(Sour spicy veg, dry curry made by seasonal vegetables tempered in red chilly &amp; cumin seed toasted with light gravy)</p><p><strong>Paneer Butter Masala</strong> - Rs. 450</p><p>(Dice of homemade cheese, deep fried &amp; braised in tasty makhani)</p><p><strong>Murgh Butter Masala</strong> - Rs. 450</p><p>(Dice of charcoal oven chicken tandoori, makhani gravy, Indian spices on top, boiled egg grated with cream julienne)</p><p><strong>Chicken Masala</strong> - Rs. 450</p><p>(Cube chicken with bone cooked in Indian spices on top of cream julienne ginger)</p><p><strong>Mutton Masala</strong> - Rs. 600</p><p>(Cube mutton with bone cooked in Indian spices on top of cream julienne ginger)</p><p><strong>Mattar Paneer</strong> - Rs. 400</p><p>(Fresh green peas, homemade cottage cheese &amp; Indian spices on top with cream julienne ginger)</p><p>Plain Rice - Rs. 150</p><p>Roti - Rs. 120</p><p>(Homemade bread 4 pieces)</p><p>Plain Curd or Yoghurt - Rs. 150</p><p>Raita Choice - Rs. 200</p><p>Chinese Special Kitchen</p><p>Schezwan Chicken with Rice - Rs. 500</p><p>Sliced Chicken &amp; Oyster sauce with rice - Rs. 500</p><p>Fish with Schezwan sauce served with rice - Rs. 500</p><p>Sliced Chicken &amp; Black Bean sauce served with rice - Rs. 500</p><p>Chicken Manchurian served with rice - Rs. 500</p><p>Veg. Manchurian served with rice - Rs. 450</p><p>Hot garlic chicken served with rice - Rs. 450</p><p>Hot Garlic fish served with rice - Rs. 500</p><p>Shredded chicken - Rs. 450</p><p>Prawn Mixed veg served with rice - Rs. 600</p><p><strong>Momos</strong></p><p><strong>Steamed-Fried-Kothey-Chilly (C)-Jhol</strong></p><p>Vegetables - Rs. 250-Rs. 300-Rs. 300-Rs. 350-Rs. 300</p><p>Chicken - Rs. 300-Rs. 350-Rs. 350-Rs. 400 Rs. 350</p><p><strong>Chopsuey</strong></p><p><strong>American Chopsuey</strong> - Rs. 450</p><p>(Crispy noodles, shredded chicken, Chinese style mixed vegetables, mushroom, baby corn, topped with a fried egg)</p><p><strong>Chinese Chopsuey</strong> - Rs. 450</p><p>(Crispy Noodle, marinated shredded mixed mean, Chinese style mixed vegetables, mushroom, baby corn, topped with julienne cut omelette)</p><p><strong>Fried Noodles </strong>(Delicious homemade noodles)</p><p>Veg - Rs. 250</p><p>Chicken - Rs. 270</p><p>Egg - Rs. 270</p><p>Pork - Rs. 300</p><p>Mixed - Rs. 400</p><p><strong>Fried Rice</strong> (Steamed long grain rice, stir-fried)</p><p>Veg - Rs. 250</p><p>Chicken - Rs. 350</p><p>Egg - Rs. 270</p><p>Mixed - Rs. 400</p><p><strong>Nasi Goreng</strong> - Rs. 400</p><p>(Malaysian style fried rice with prawn, chicken and topped with a fried egg)</p><p><strong>Sandwich/Burger/Spring Rolls</strong></p><p><strong>The Simal Special Sandwich</strong> - Rs. 450</p><p>(A triple-decker sandwich with lettuce, cheese, chicken bacon, tomato, cucumber, and fried egg served with french fries)</p><p><strong>Ham and Cheese grilled sandwich</strong> - Rs. 375</p><p>(Ham and cheese grilled sandwich served with french fries)</p><p><strong>Chicken Sandwich</strong> - Rs. 350</p><p>(Chopped chicken, marinated mayonnaise sauce, side salad, tomato sauce)</p><p><strong>Nepali Burger</strong> - Rs. 400</p><p>(Minced chicken marinated in fresh herbs served with french fries)</p><p><strong>Vegetable Burger</strong></p><p>(minced mixed vegetables chopped, served with french fries)</p><p><strong>Chicken Spring Roll</strong> - Rs. 400</p><p>(Shredded Julian Chicken, mixed vegetable noodles served with french fries)</p><p><strong>Burrito Chicken Wrap</strong> - Rs. 350</p><p>(Julliane cut lettuce, onion, tomato, shredded chicken, seasoning)</p><p>Chicken Katti Roll - Rs. 350</p><p><strong>Pizza</strong></p><p>Mixed Pizza - Rs. 500</p><p>Mushroom Pizza - Rs. 400</p><p>Tomato Pizza - Rs. 350</p><p><strong>Snacks&nbsp;</strong></p><p>Chicken Drumstick - Rs. 350</p><p>Chicken Sekuwa - Rs. 400</p><p>Chicken Chilly Boneless - Rs. 450</p><p>Chicken Choila - Rs. 400</p><p>Tawa Chicken - Rs. 450</p><p>Chicken Sadeko - Rs. 380</p><p>Chicken Roast - Rs. 450</p><p>French Fries - Rs. 250</p><p>Aaloo Jeera - Rs. 250</p><p>Aaloo Sadeko - Rs. 250</p><p>Veg. Pakauda - Rs. 300</p><p>Peanuts Sadeko - Rs. 250</p><p>Masala / Plain Papad - Rs. 150</p><p>Nachos Sadeko - Rs. 450</p><p>Paneer Chilly - Rs. 450</p><p>Pork Sadeko - Rs. 450</p><p>Pork Chilly - Rs. 450</p><p>Pork Sekewa - Rs. 450</p><p>Mushroom Chilly - Rs. 350</p><p>Prawn Chilly - Rs. 900</p><p>Butterfly Prawn - Rs. 850</p><p>Spicy Wings - Rs. 450</p><p><strong>Dessert</strong></p><p>Fruit Salad - Rs. 250</p><p>Assorted Icecream - Rs. 300</p><p>Lalmon (per pcs) - Rs. 50</p><p>Toffee Banana - Rs. 250</p><p><strong>Lassi</strong></p><p>Banana Lassi - Rs. 200</p><p>Masala Lassi - Rs. 300</p><p>Plain Lassi (Sweet Lassi) - Rs. 150</p><p><strong>Fresh Juice</strong></p><p>Orange Juice - Rs. 300</p><p>Watermelon - Rs. 250</p><p>Pineapple - Rs. 300</p><p>Pomegranate - Rs. 450</p><p><strong>Hot and Cold Beverages</strong></p><p>Hot Lemon with Honey - Rs. 200</p><p>Ice Tea - Rs. 100</p><p>Expresso - Rs. 125</p><p>Expresso Doppio - Rs. 160</p><p>Americano - Rs. 150</p><p>Cappuccino - Rs. 250</p><p>Cafe Latte - Rs. 200</p><p>Ice Coffee - Rs. 150</p><p>Ice Americano - Rs. 250</p><p>Hot Chocolate - Rs. 200</p><p><strong>Milk Shake</strong> - Rs. 200</p><p>(Flavors; Chocolate, Banana, Strawberry)</p><p>Mint Tea - Rs. 100</p><p>Green Tea - Rs. 100</p><p>Jasmine Tea - Rs. 100</p><p><strong>Tea/Coffee</strong>&nbsp;</p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>&nbsp;Cup - Small Pot - Big Pot</strong>&nbsp;</p><p>Milk Tea - Rs. 100 Rs. 350 Rs. 450</p><p>Black Tea - Rs. 70 Rs. 150 Rs. 250</p><p>Masala Tea - Rs. 120 Rs. 400 Rs. 500&nbsp;</p><p>Milk Coffee - Rs. 150 Rs. 450 Rs. 550</p><p>Black Coffee - Rs. 100 Rs. 250 Rs. 350</p><p><strong>Beer</strong></p><p>Carlsberg (650 ml) - Rs. 650</p><p>Tuborg (650 ml) - Rs. 650</p><p>Everest (650 ml) - Rs. 600</p><p>Gorkha Premium(650 ml) - Rs. 600</p><p>Budweiser - Rs. 650</p><p>Gorkha Strong (650 ml) - Rs. 600</p><p>Nepal Ice (650 ml) - Rs. 600</p><p><strong>Wine</strong></p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <strong>Per Glass-Bottle</strong></p><p>Nepali red wine - Rs. 900 - Rs. 2400</p><p>Imported red wine-Rs. 1100 - Rs. 3000</p><p>White wine - Rs. 1100 - Rs. 3000</p><p><strong>Soft Drinks</strong></p><p>Coke - Rs. 120</p><p>Fanta - Rs. 120</p><p>Sprite - Rs. 120</p><p>Mineral Water (1 ltr) - Rs. 50</p><p><strong>Hard Beverage</strong></p><p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<strong>30 ml - 60 ml - Bottle</strong></p><p>Black label - Rs. 500 Rs. 950 Rs. 14500</p><p>Red label - Rs. 400 Rs. 750 Rs. 11500</p><p>Khukuri Rum - Rs. 200 Rs. 380 Rs. 4500</p><p>Malibu Rum - Rs. 400 Rs. 750 Rs. 11500</p><p>8848 Vodka - Rs. 200 Rs. 380 Rs. 4500</p><p>Gin (Gordons) -Rs. 400 Rs. 750 Rs. 11500</p><p>Brandy - Rs. 400 Rs. 750 Rs. 12000</p><p>White Tequila - Rs. 280 Rs. 500 Rs. 11500</p><p>Signature - Rs. 200 Rs. 380 Rs. 4500</p><p>Chivas - Rs. 645 Rs. 1290 Rs. 15500</p><p>Old Durbar (Regular)-Rs. 250 Rs. 450 Rs. 5200</p><p>Old Durbar (Black Chimney)-Rs. 280 Rs. 500 Rs. 6500</p>', 1, NULL, NULL, NULL, NULL, 'Menu | Restaurant Menu', 'Menu, restaurant menu, food and drinks price', 'The menu is a food and drinks list with the cost according to cooking items at Hotel Simal Kathmandu Nepal. ', '2022-12-03 02:24:02', '2023-01-13 01:48:34'),
	(16, 0, 'Blogs', 'blogs', NULL, '<p>Blogs</p>', 1, NULL, NULL, NULL, NULL, 'Blogs', 'Blogs', 'Blogs', '2023-02-13 00:12:33', '2023-02-13 00:12:33');

-- Dumping structure for table hotelchurchure.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.password_resets: ~0 rows (approximately)

-- Dumping structure for table hotelchurchure.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table hotelchurchure.recommendations
CREATE TABLE IF NOT EXISTS `recommendations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.recommendations: ~4 rows (approximately)
INSERT INTO `recommendations` (`id`, `title`, `link`, `image`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'Tripadvisor', 'https://www.tripadvisor.com/Hotel_Review-g293890-d25111848-Reviews-Hotel_Simal-Kathmandu_Kathmandu_Valley_Bagmati_Zone_Central_Region.html', NULL, 1, '2022-12-01 11:02:59', '2022-12-01 11:35:52'),
	(2, 'agoda', 'https://www.agoda.com/hotel-simal-pvt-ltd/hotel/kathmandu-np.html', NULL, 1, '2022-12-01 11:14:56', '2022-12-02 08:52:40'),
	(3, 'Booking.com', 'https://www.booking.com/hotel/np/simal-pvt-ltd.en-gb.html', NULL, 1, '2022-12-01 11:17:03', '2022-12-02 08:50:17'),
	(4, 'Expedia', 'https://www.expedia.com/Kathmandu-Hotels-Hotel-Simal-Pvt-Ltd.h89267596.Hotel-Information', NULL, 1, '2022-12-02 06:19:28', '2022-12-02 08:51:57');

-- Dumping structure for table hotelchurchure.redirects
CREATE TABLE IF NOT EXISTS `redirects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `from_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.redirects: ~0 rows (approximately)

-- Dumping structure for table hotelchurchure.reviews
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` tinyint NOT NULL DEFAULT '0',
  `reviewer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reviewer_subtitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `extra` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.reviews: ~2 rows (approximately)
INSERT INTO `reviews` (`id`, `title`, `details`, `rating`, `reviewer_name`, `reviewer_subtitle`, `is_active`, `extra`, `deleted_at`, `created_at`, `updated_at`, `is_featured`) VALUES
	(1, 'Amazing service !!!', 'Excellent service, lovely meal too. Starters were  very tasty and freshly cooked. The Prawn Pathos was also delicious. Great to be back here after many years', 4, 'Jonh Doe', 'Facebook Inc.', 1, NULL, '2022-11-18 03:11:28', '2022-09-15 04:58:40', '2022-11-18 03:11:28', 1),
	(2, 'Sit enim sed et sit unde do optio est Sit enim', 'Et quibusdam deserunt quia enim ratione cum odit perspiciatis est tenetur sint voluptate est sequi non sint laborum Vel nesciunt', 3, 'MacKensie Avila', 'Et quibusdam deserun', 1, NULL, '2022-11-18 03:11:34', '2022-09-15 05:24:10', '2022-11-18 03:11:34', 1);

-- Dumping structure for table hotelchurchure.rooms
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `facilities` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `extra` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.rooms: ~5 rows (approximately)
INSERT INTO `rooms` (`id`, `title`, `price`, `details`, `facilities`, `is_active`, `extra`, `deleted_at`, `created_at`, `updated_at`) VALUES
	(1, 'Single bed rooms', 30, '<p>Two well-furnished single bedrooms with an attached bathroom to suit a single person facilitating Lift, Guard and Housekeeping service. Our hotel check-out time is 12:00 PM and check-in time is 2:00 PM.&nbsp;</p>', '[{"facility": "Comfortable single bed with  8\\" mattress"}, {"facility": "Air conditioning, hot shower, Western toilet"}, {"facility": "One mineral water bottle, Free Wi-Fi"}, {"facility": "32\\" flat screen TV, Cupboard, Electric Kettle"}, {"facility": "Dustbin, Intercom phone, chest drawer, charging socket"}]', 1, NULL, NULL, '2022-09-15 01:34:59', '2023-02-04 22:17:30'),
	(2, 'Twins bedroom', 57, '<p>Fifteen well-furnished twin bedrooms with an attached bathroom to suit two people facilitate Lift, Guard and Housekeeping service. This hotel check-out time is 12:00 PM and check-in time is 2:00 PM.&nbsp;</p>', '[{"facility": "Comfortable twin beds with  8\\" mattress, Attached bathroom with a western toilet"}, {"facility": "Air conditioning, hot shower, cupboard"}, {"facility": "Single seater sofa set, Mineral water, free Wi-Fi"}, {"facility": "43\\" flat screen TV, Electric Kettle, tea, coffee bag"}, {"facility": "Working table, Chest drawer, Charging socket"}, {"facility": "Mini bar"}, {"facility": "Mirror and Toiletries"}]', 1, NULL, NULL, '2022-09-15 02:25:08', '2023-12-02 23:00:06'),
	(3, 'Test', 12, '<p>test</p>', '[{"facility": "test"}, {"facility": "test"}, {"facility": "test asdfa"}]', 1, NULL, '2022-11-18 03:19:01', '2022-11-18 03:18:43', '2022-11-18 03:19:01'),
	(4, 'Suite Rooms with balcony ', 63, '<p>Nine well-furnished Sweet rooms with a balcony possess an attached bathroom to suit two people facilitating Lift, Guard and Housekeeping service. Our hotel check-out time is 12:00 PM and check-in time is 2:00 PM.&nbsp;</p>', '[{"facility": "One double bed, one single bed with a comfortable 8\\" mattress with balcony"}, {"facility": "Attached bathroom with a western toilet"}, {"facility": "Air conditioning, cupboard, Charging socket, Chest drawer"}, {"facility": "43\\" flat screen TV, Electric Kettle, Free Wi-Fi, Intercom phone"}, {"facility": "Single seater sofa set, Mineral water, working table, Minibar"}, {"facility": "Hot shower, mirror and Toiletries"}]', 1, NULL, NULL, '2022-11-18 04:24:12', '2023-12-02 23:00:32'),
	(5, 'Deluxe king rooms', 57, '<p>Twelve well-furnished Deluxe king room with master bed maintains an attached bathroom to suit a couple or single facilitating Lift, Guard and Housekeeping service. The hotel check-out time is 12:00 PM and check-in time is 2:00 PM.&nbsp;</p>', '[{"facility": "Comfortable Master Bed With 8\\" mattresses, Attached bathroom with a western toilet"}, {"facility": "Air conditioning, cupboard, Intercom phone, charging socket, Chest drawer"}, {"facility": "43\\" flat screen TV, free Wi-Fi, Intercom phone, mineral water"}, {"facility": "Electric Kettle, tea, coffee, working table, Minibar, dustbin"}, {"facility": "Single seater sofa set, Hot shower, mirror and Toiletries"}]', 1, NULL, NULL, '2022-11-18 04:39:34', '2023-12-02 23:00:44');

-- Dumping structure for table hotelchurchure.slides
CREATE TABLE IF NOT EXISTS `slides` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL,
  `order_by` int NOT NULL DEFAULT '0',
  `in_home` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.slides: ~4 rows (approximately)
INSERT INTO `slides` (`id`, `title`, `details`, `image`, `link`, `status`, `order_by`, `in_home`, `created_at`, `updated_at`) VALUES
	(2, 'Hotel Lobby', NULL, NULL, NULL, 1, 0, '0', '2022-08-01 10:22:09', '2023-01-20 22:30:19'),
	(9, 'Family Bed Room', NULL, NULL, NULL, 1, 0, '0', '2022-11-18 03:04:07', '2023-01-20 22:28:58'),
	(10, 'Floor Restaurant ', NULL, NULL, NULL, 1, 0, '0', '2022-11-18 04:08:55', '2023-01-20 22:29:31'),
	(11, 'Bar', NULL, NULL, NULL, 1, 0, '0', '2023-01-20 22:27:41', '2023-01-20 22:27:41');

-- Dumping structure for table hotelchurchure.socials
CREATE TABLE IF NOT EXISTS `socials` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.socials: ~6 rows (approximately)
INSERT INTO `socials` (`id`, `title`, `icon`, `link`, `status`, `created_at`, `updated_at`) VALUES
	(3, 'Facebook', 'facebook', 'https://www.facebook.com/hotelsimal', 1, '2022-12-02 05:15:09', '2022-12-02 05:15:09'),
	(4, 'Instagram', 'instagram', 'https://www.instagram.com/hotelsimal', 1, '2022-12-02 05:15:30', '2022-12-02 05:58:06'),
	(6, 'Twitter', 'twitter', 'https://twitter.com/hotel_simal', 1, '2022-12-02 05:17:59', '2022-12-02 05:17:59'),
	(7, 'Pinterest', 'pinterest', 'https://www.pinterest.com/hotelsimal/', 1, '2022-12-02 05:18:21', '2022-12-02 05:18:21'),
	(8, 'Linkedin', 'linkedin', 'https://www.linkedin.com/in/hotel-simal/', 1, '2022-12-02 05:18:49', '2022-12-02 05:18:49'),
	(9, 'Youtube', 'youtube', 'https://www.youtube.com/@hotelsimal', 1, '2022-12-02 06:09:01', '2022-12-02 06:09:01');

-- Dumping structure for table hotelchurchure.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table hotelchurchure.users: ~0 rows (approximately)
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'Admin', 'admin@hotelchurchure.com', NULL, '$2y$10$9KHyvJPCsgCi01hZX26L5u/aA5jQ9PWGzbTqjQ82mJPrqQaCUw.iu', 'nFqHBKbvmVILdq3omoBtZUycynKEySJoPTI8JDtHzHbsV8fX6OzRU9lFdErM', '2022-09-14 10:29:43', '2022-09-14 10:29:43');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
